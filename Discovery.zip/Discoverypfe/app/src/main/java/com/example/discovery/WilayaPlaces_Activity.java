package com.example.discovery;

import static android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;

import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsetsController;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class WilayaPlaces_Activity extends AppCompatActivity {

    wilaya_places_adapter adapter;
    RecyclerView recyclerView;
    TextView place_name;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wilaya_places);
        Setting_Action_Bar_Status_Bar();
        initialisation();
        setRecycler();


    }

    public void initialisation() {
        place_name = findViewById(R.id.wilaya_text);
        place_name.setText(getIntent().getStringExtra("wilaya"));
        recyclerView = findViewById(R.id.recycler);
    }

    public void setRecycler() {

        switch (getIntent().getStringExtra("wilaya")) {

            case "Alger":
               adapter = new wilaya_places_adapter(Utils.AlgerList(), WilayaPlaces_Activity.this);
                break;
            case "Oran":
                adapter = new wilaya_places_adapter(Utils.OranList(), WilayaPlaces_Activity.this);
                break;
            case "Blida":
                adapter = new wilaya_places_adapter(Utils.BlidaList(), WilayaPlaces_Activity.this);

                break;
            case "Boumerdès":
                adapter = new wilaya_places_adapter(Utils.BoumerdèsList(), WilayaPlaces_Activity.this);

                break;
            case "Constantine":
                adapter = new wilaya_places_adapter(Utils.ConstantineList(), WilayaPlaces_Activity.this);
                 break;
            case "Annaba":
                adapter = new wilaya_places_adapter(Utils.AnnabaList(), WilayaPlaces_Activity.this);

                break;
            case "Mostaganem":
                adapter = new wilaya_places_adapter(Utils.MostaganemList(), WilayaPlaces_Activity.this);

                break;
            case "Tizi Ouzou":
                adapter = new wilaya_places_adapter(Utils.Tizi_OuzouList(), WilayaPlaces_Activity.this);

                break;
            case "Béjaïa":
                adapter = new wilaya_places_adapter(Utils.BéjaïaList(), WilayaPlaces_Activity.this);

                break;
            case "Tipaza":
                adapter = new wilaya_places_adapter(Utils.TipazaList(), WilayaPlaces_Activity.this);

                break;
            case "Jijel":
                adapter = new wilaya_places_adapter(Utils.JijelList(), WilayaPlaces_Activity.this);

                break;
            case "Sétif":
                adapter = new wilaya_places_adapter(Utils.SétifList(), WilayaPlaces_Activity.this);

                break;
            case "Skikda":
                adapter = new wilaya_places_adapter(Utils.SkikdaList(), WilayaPlaces_Activity.this);

                break;
            case "Mila":
                adapter = new wilaya_places_adapter(Utils.MilaList(), WilayaPlaces_Activity.this);

                break;
            case "Chlef":
                adapter = new wilaya_places_adapter(Utils.ChlefList(), WilayaPlaces_Activity.this);

                break;
            case "Bordj Bou Arreridj":
                adapter = new wilaya_places_adapter(Utils.Bordj_Bou_ArreridjList(), WilayaPlaces_Activity.this);

                break;
            case "Bouira":
                adapter = new wilaya_places_adapter(Utils.BouiraList(), WilayaPlaces_Activity.this);

                break;
            case "Aïn Defla":
                adapter = new wilaya_places_adapter(Utils.Aïn_DeflaList(), WilayaPlaces_Activity.this);

                break;
            case "Aïn Témouchent":
                adapter = new wilaya_places_adapter(Utils.Aïn_TémouchentList(), WilayaPlaces_Activity.this);

                break;
            case "Relizane":
                adapter = new wilaya_places_adapter(Utils.RelizaneList(), WilayaPlaces_Activity.this);

                break;
            case "Mascara":
                adapter = new wilaya_places_adapter(Utils.MascaraList(), WilayaPlaces_Activity.this);

                break;
            case "El Tarf":
                adapter = new wilaya_places_adapter(Utils.El_TarfList(), WilayaPlaces_Activity.this);

                break;
            case "Guelma":
                adapter = new wilaya_places_adapter(Utils.GuelmaList(), WilayaPlaces_Activity.this);

                break;
            case "Tlemcen":
                adapter = new wilaya_places_adapter(Utils.TelemcenList(), WilayaPlaces_Activity.this);

                break;
            case "Souk Ahras":
                adapter = new wilaya_places_adapter(Utils.Souk_AhrasList(), WilayaPlaces_Activity.this);

                break;
            case "Tissemsilt":
                adapter = new wilaya_places_adapter(Utils.TissemsiltList(), WilayaPlaces_Activity.this);

                break;
            case "Batna":
                adapter = new wilaya_places_adapter(Utils.BatnaList(), WilayaPlaces_Activity.this);

                break;
            case "Médéa":
                adapter = new wilaya_places_adapter(Utils.MédéaList(), WilayaPlaces_Activity.this);

                break;
            case "Oum El Bouaghi":
                adapter = new wilaya_places_adapter(Utils.Oum_El_ouaghiList(), WilayaPlaces_Activity.this);

                break;
            case "Sidi Bel Abbès":
                adapter = new wilaya_places_adapter(Utils.Sidi_Bel_AbbèsList(), WilayaPlaces_Activity.this);

                break;
            case "M'Sila":
                adapter = new wilaya_places_adapter(Utils.MSilaList(), WilayaPlaces_Activity.this);

                break;
            case "Saïda":
                adapter = new wilaya_places_adapter(Utils.SaïdaList(), WilayaPlaces_Activity.this);

                break;
            case "Tébessa":
                adapter = new wilaya_places_adapter(Utils.TébessaList(), WilayaPlaces_Activity.this);

                break;
            case "Djelfa":
                adapter = new wilaya_places_adapter(Utils.DjelfaList(), WilayaPlaces_Activity.this);

                break;
            case "Tiaret":
                adapter = new wilaya_places_adapter(Utils.TiaretList(), WilayaPlaces_Activity.this);

                break;
            case "Khenchela":
                adapter = new wilaya_places_adapter(Utils.KhenchelaList(), WilayaPlaces_Activity.this);

                break;
            case "Biskra":
                adapter = new wilaya_places_adapter(Utils.BiskralaList(), WilayaPlaces_Activity.this);

                break;
            case "El M'Ghair":
                adapter = new wilaya_places_adapter(Utils.MghirList(), WilayaPlaces_Activity.this);

                break;
            case "Laghouat":
                adapter = new wilaya_places_adapter(Utils.LaghouatList(), WilayaPlaces_Activity.this);

                break;
            case "Ouled Djellal":
                adapter = new wilaya_places_adapter(Utils.Ouled_DjellalList(), WilayaPlaces_Activity.this);

                break;
            case "Touggourt":
                adapter = new wilaya_places_adapter(Utils.TouggourtList(), WilayaPlaces_Activity.this);

                break;
            case "Oued":
                adapter = new wilaya_places_adapter(Utils.OuedList(), WilayaPlaces_Activity.this);

                break;
            case "Naâma":
                adapter = new wilaya_places_adapter(Utils.NaâmaList(), WilayaPlaces_Activity.this);

                break;
            case "Ghardaïa":
                adapter = new wilaya_places_adapter(Utils.GhardaïaList(), WilayaPlaces_Activity.this);

                break;
            case "El Bayadh":
                adapter = new wilaya_places_adapter(Utils.El_BayadhList(), WilayaPlaces_Activity.this);

                break;
            case "Ouargla":
                adapter = new wilaya_places_adapter(Utils.OuarglaList(), WilayaPlaces_Activity.this);

                break;
            case "Timimoun":
                adapter = new wilaya_places_adapter(Utils.TimimounOList(), WilayaPlaces_Activity.this);


                break;
            case "Béchar":
                adapter = new wilaya_places_adapter(Utils.BécharList(), WilayaPlaces_Activity.this);

                break;
            case "Adrar":
                adapter = new wilaya_places_adapter(Utils.AdrarList(), WilayaPlaces_Activity.this);

                break;
            case "Meniaa":
                adapter = new wilaya_places_adapter(Utils.MeniaaList(), WilayaPlaces_Activity.this);

                break;
            case "Béni Abbès":
                adapter = new wilaya_places_adapter(Utils.Béni_AbbèsList(), WilayaPlaces_Activity.this);

                break;
            case "In Salah":
                adapter = new wilaya_places_adapter(Utils.In_SalahList(), WilayaPlaces_Activity.this);

                break;
            case "Tamanrasset":
                adapter = new wilaya_places_adapter(Utils.TamanrassetList(), WilayaPlaces_Activity.this);

                break;
            case "Tindouf":
                adapter = new wilaya_places_adapter(Utils.TindoufList(), WilayaPlaces_Activity.this);

                break;
            case "Djanet":
                adapter = new wilaya_places_adapter(Utils.DjanetList(), WilayaPlaces_Activity.this);

                break;
            case "Illizi":
                adapter = new wilaya_places_adapter(Utils.IlliziList(), WilayaPlaces_Activity.this);

                break;
            case "Bordj Badji Mokhtar":
                adapter = new wilaya_places_adapter(Utils.Bordj_Badji_MokhtarList(), WilayaPlaces_Activity.this);

                break;
            case "In Guezzam":
                adapter = new wilaya_places_adapter(Utils.In_GuezzamList(), WilayaPlaces_Activity.this);

                break;


        }
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void Setting_Action_Bar_Status_Bar() {

        //Hiding action bar
        getSupportActionBar().hide();
        // setting the keyboard
        //Utils.setUpKeybaord(findViewById(R.id.serach_page), WilayaPlaces_Activity.this);

        this.getWindow().setStatusBarColor(getResources().getColor(R.color.mainbluee));

        // to change the color of the icons in status bar to dark
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            this.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(APPEARANCE_LIGHT_STATUS_BARS, APPEARANCE_LIGHT_STATUS_BARS);
        }
        // to change the color of the icons in the navigation bar to dark
        this.getWindow().setNavigationBarColor(getResources().getColor(R.color.mainbluee)); //setting bar color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            this.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS, WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
    }
}