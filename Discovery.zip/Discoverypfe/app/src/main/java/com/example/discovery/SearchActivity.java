package com.example.discovery;

import static android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsetsController;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ProgressBar;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    public static ProgressBar progressBar;
    AutoCompleteTextView searchField;
    RecyclerView recyclerView;
    DatabaseReference root;
    public static Search_adapter adapter;
    ShimmerFrameLayout shimmerFrameLayout;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Setting_Action_Bar_Status_Bar();
        initialisation();
        AutoCompleteByName();
    }


    public void initialisation() {
        shimmerFrameLayout = findViewById(R.id.shimmer);
        progressBar = findViewById(R.id.search_progress);
        searchField = findViewById(R.id.complete_text);
        recyclerView = findViewById(R.id.search_recycler);
        root = FirebaseDatabase.getInstance().getReference();
    }
//write few letters it'll show you the full name willaya
    public void AutoCompleteByName() {

        ArrayList<String> name = new ArrayList<>();
        for (ItemsModel i : Utils.getAllWilayas()){
            name.add(i.getProductName());
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(SearchActivity.this, android.R.layout.simple_list_item_1, name);
        searchField.setAdapter(arrayAdapter);
        searchField.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //progressBar.setVisibility(View.VISIBLE);
                String product = searchField.getText().toString();
                searchProductByName(product);
            }
        });

    }
//search wilaya
    public void searchProductByName(String productName) {
        ArrayList<ItemsModel> listo= new ArrayList<>();
        for (ItemsModel item : Utils.getAllWilayas()) {
            if (item.getProductName().equals(productName)) {
                listo.add(item);
                setRecycler(listo);

            }
        }
    }
    //displaying list of wilayas of searching
    public void setRecycler(ArrayList<ItemsModel> list) {
        adapter = new Search_adapter(list, SearchActivity.this);
        SearchActivity.progressBar.setVisibility(View.GONE);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void Setting_Action_Bar_Status_Bar() {

        //Hiding action bar
        getSupportActionBar().hide();
        // setting the keyboard
        Utils.setUpKeybaord(findViewById(R.id.serach_page), SearchActivity.this);

        this.getWindow().setStatusBarColor(getResources().getColor(R.color.white));

        // to change the color of the icons in status bar to dark
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            this.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(APPEARANCE_LIGHT_STATUS_BARS, APPEARANCE_LIGHT_STATUS_BARS);
        }
        // to change the color of the icons in the navigation bar to dark
        this.getWindow().setNavigationBarColor(getResources().getColor(R.color.white)); //setting bar color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            this.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS, WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
    }


}