package com.example.discovery;

import static android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsetsController;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.denzcoskun.imageslider.ImageSlider;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {
    ImageView search, user_image;
    public static ImageSlider imageSlider;
    TextView HeaderText, popularItemsText, viewAllText2;
    DatabaseReference Root;
    public static Search_adapter adapter;
    MaterialCardView parent_slide_card, user_img;
    public static RecyclerView recyclersecond;
    public static ProgressBar progressBar1;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialisation();
        handlingOnClicks();
        SettingUpImageSlider();
        SettingRecyclers();
        SettingAnimation();
        Setting_Action_Bar_Status_Bar();
        SettingHeaderTextUser();

    }


    private void SettingAnimation() {
        Animations.FromeRightToLeftCard(parent_slide_card);
//        Animations.FromeLeftToRight(HeaderText);
        Animations.FromeLeftToRight(popularItemsText);
        Animations.FromRightToLeft1(viewAllText2);
//        Animations.FromeLeftToRight1(secondHeaderText);

    }

    public void initialisation() {
        user_image = findViewById(R.id.img_user_profile);
        search = findViewById(R.id.search);
        user_img = findViewById(R.id.user_profile);
        progressBar1 = findViewById(R.id.populaire_items_progress);
        HeaderText = findViewById(R.id.header_text);
        popularItemsText = findViewById(R.id.popular_items_text);
//        secondHeaderText = findViewById(R.id.second_header);
        viewAllText2 = findViewById(R.id.second_view_all_text);
        imageSlider = findViewById(R.id.slider);
        parent_slide_card = findViewById(R.id.parent_card);
        Root = FirebaseDatabase.getInstance().getReference();
        recyclersecond = findViewById(R.id.second_recyclerview);
    }

    public void handlingOnClicks() {
        viewAllText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, All_wilayas_Activity.class));
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });
        user_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Profile_Activity.class));
            }
        });
    }

    public void SettingUpImageSlider() {
        imageSlider.setImageList(Utils.GetSlideList(), true);
    }

    public void SettingRecyclers() {
        // setting second recycler
        adapter = new Search_adapter(Utils.getAllWilayas(), getApplicationContext());
        recyclersecond.setAdapter(adapter);
        recyclersecond.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));

    }

    public void SettingHeaderTextUser() {
        Root.child("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    UserModel model = snapshot.getValue(UserModel.class);
                    if (!model.getName().equals("")){
                        HeaderText.setText("Bonjour"+" "+model.getName()+"!");
                    } else {
                        HeaderText.setText("Bonjour !");
                    }
                    if (!model.getImage().equals("")) {
                        Picasso.get().load(model.getImage()).into(user_image);
                    } else {
                        user_image.setImageResource(R.drawable.ic_avataaars);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void Setting_Action_Bar_Status_Bar() {

        //Hiding action bar
        getSupportActionBar().hide();
        // setting the keyboard
        Utils.setUpKeybaord(findViewById(R.id.parentt), MainActivity.this);

        this.getWindow().setStatusBarColor(getResources().getColor(R.color.mainbluee));

        // to change the color of the icons in status bar to dark
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            this.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(APPEARANCE_LIGHT_STATUS_BARS, APPEARANCE_LIGHT_STATUS_BARS);
        }
        // to change the color of the icons in the navigation bar to dark
        this.getWindow().setNavigationBarColor(getResources().getColor(R.color.mainbluee)); //setting bar color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            this.getWindow().getDecorView().getWindowInsetsController().setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS, WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
    }

}