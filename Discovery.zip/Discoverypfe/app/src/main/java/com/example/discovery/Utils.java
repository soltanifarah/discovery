package com.example.discovery;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;
import java.util.List;


public class Utils {

    public static int isHere = 0;
    public static int existss = 0;
    public static List<SlideModel> slideModels;

    // hide the keyboard when we clicks any where(better user experience )

    public static void SettingKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        if (inputMethodManager.isAcceptingText()) {
            inputMethodManager.hideSoftInputFromWindow(
                    activity.getCurrentFocus().getWindowToken(),
                    0
            );
        }
    }

    // hiding the keyboard when we clicks any where ( better user experience )

    public static void setUpKeybaord(View view, Activity activity) {
        // Set up touch listener for non-text box views to hide keyboard.
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    Utils.SettingKeyboard(activity);
                    return false;
                }
            });
        }
        //If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setUpKeybaord(innerView, activity);
            }
        }

    }

    public static List<SlideModel> GetSlideList() {
        if (slideModels == null) {
            slideModels = new ArrayList<>();
        }
        slideModels.clear();
        slideModels.add(new SlideModel("https://www.middleeasteye.net/sites/default/files/image_from_ios_5_1.jpg"));
        slideModels.add(new SlideModel("https://b.otcdn.com/imglib/hotelfotos/8/735/hotel-az-htels-zephyr-mostaganem-20201006084517.jpg"));
        slideModels.add(new SlideModel("https://www.aps.dz/media/k2/items/cache/5014bf9705e597e4d1123f58b425eb5b_M.jpg"));
        slideModels.add(new SlideModel("https://www.aps.dz/media/k2/items/cache/a11c12478b5ee16b47cffa797f9ab068_M.jpg"));
        slideModels.add(new SlideModel("https://www.tunisiepromo.com/wp-content/uploads/2018/09/Oran-guide-touristique-alg%C3%A9rie2.jpg"));
        slideModels.add(new SlideModel("https://www.crowe.com/dz/-/media/Crowe/Firms/Middle-East-and-Africa/dz/CroweHorwathDZ/Images/algeria.jpg?h=539&la=fr-FR&w=960&modified=00010101000000&hash=CBFA3890340E9154B6CDA5710E750D1AA73938E2"));
        slideModels.add(new SlideModel("https://www.state.gov/wp-content/uploads/2022/02/Algeria-1536x944.png"));
        slideModels.add(new SlideModel("https://www.telegraph.co.uk/content/dam/Travel/2020/March/algeria-constantine.jpg?imwidth=960"));
        slideModels.add(new SlideModel("https://www.middleeasteye.net/sites/default/files/styles/article_page/public/images-story/algeria_backpacking.jpg?itok=iWOPXqNt"));

        return slideModels;
    }

    public static ArrayList<ItemsModel> getAllWilayas() {

        ArrayList<ItemsModel> list = new ArrayList<>();
        list.add(new ItemsModel("Alger", "2511", "https://pix6.agoda.net/geo/city/1194/1_1194_02.jpg?ca=6&ce=1&s=1920x822", false));
        list.add(new ItemsModel("Oran", "688", "https://www.entv.dz/wp-content/uploads/2020/07/oran.jpg", false));
        list.add(new ItemsModel("Blida", "591", "https://media-cdn.tripadvisor.com/media/photo-s/09/2f/c4/4d/place-du-1er-novembre.jpg", false));
        list.add(new ItemsModel("Boumerdès", "504", "https://www.elwatan.com/wp-content/uploads/2021/06/Boumerdes.gif", false));
        list.add(new ItemsModel("Constantine", "427", "https://airalgerie.dz/wp-content/uploads/2016/10/constantine_780x360.jpg", false));
        list.add(new ItemsModel("Annaba", "424", "https://www.aps.dz/media/k2/items/cache/bbd0e549f15bc46eb4fb923399190441_M.jpg", false));
        list.add(new ItemsModel("Mostaganem", "325", "https://www.dzbreaking.com/wp-content/uploads/2018/03/mosta.jpg", false));
        list.add(new ItemsModel("Tizi Ouzou", "316", "https://www.elwatan.com/wp-content/uploads/2020/11/Parc-port-Tigzirt.jpg", false));
        list.add(new ItemsModel("Béjaïa", "279", "https://www.thecasbahpost.com/wp-content/uploads/2016/08/Bejaia-1.jpg", false));
        list.add(new ItemsModel("Tipaza", "273", "https://voyagez-en-algerie.com/wp-content/uploads/2021/06/Tipaza-Le-Mausolee-Royal-de-Mauretanie.jpg", false));
        list.add(new ItemsModel("Jijel", "247", "https://airalgerie.dz/wp-content/uploads/2016/10/jijel2_780x360.jpg", false));
        list.add(new ItemsModel("Sétif", "229", "https://www.aps.dz/media/k2/items/cache/910e7a5779e2b384b246a9530a4806ee_M.jpg", false));
        list.add(new ItemsModel("Skikda", "223", "https://upload.wikimedia.org/wikipedia/commons/c/c3/Collo_skikda.jpg", false));
        list.add(new ItemsModel("Mila", "220", "https://media-cdn.sygictraveldata.com/media/800x600/612664395a40232133447d33247d383738383339353432", false));
        list.add(new ItemsModel("Chlef", "209", "https://airalgerie.dz/wp-content/uploads/2016/10/chlef_780x360.jpg", false));
        list.add(new ItemsModel("Bordj Bou Arreridj", "160", "https://i0.wp.com/harba-dz.com/wp-content/uploads/2020/10/Wilaya-de-Bordj-Bou-Arreridj-El-Golea.jpg?fit=875%2C768&ssl=1", false));
        list.add(new ItemsModel("Bouira", "157", "https://upload.wikimedia.org/wikipedia/commons/7/79/StatueBouira.jpg", false));
        list.add(new ItemsModel("Aïn Defla", "156", "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/12/4d/01/b3/hoceinia.jpg?w=500&h=300&s=1", false));
        list.add(new ItemsModel("Aïn Témouchent", "156", "https://www.aps.dz/media/k2/items/cache/6da9f4518433cb2bd3646add1696bbb1_M.jpg", false));
        list.add(new ItemsModel("Relizane", "152", "https://www.aps.dz/media/k2/items/cache/6528207fcedcce35654be55197a20b7f_M.jpg", false));
        list.add(new ItemsModel("Mascara", "132", "https://www.algerie360.com/wp-content/uploads/2017/04/mascara.jpg?x30148", false));
        list.add(new ItemsModel("El Tarf", "122", "https://www.aps.dz/media/k2/items/cache/40c13ee937f63999f7299d69b0f532c2_M.jpg", false));
        list.add(new ItemsModel("Guelma", "118", "https://www.vitaminedz.com/articles/6990/6990036.jpg", false));
        list.add(new ItemsModel("Tlemcen", "105", "https://image.architonic.com/imgArc/project-1/4/5209997/fabris-partners-renaissance-tlemcen-architonic-tlemcen-exterieur-4-01.jpg", false));
        list.add(new ItemsModel("Souk Ahras", "95", "https://www.elwatan.com/wp-content/uploads/2020/06/d-un-jumelage-entre-souk-ahras-et-santa-monica-5c8a1.jpg", false));
        list.add(new ItemsModel("Tissemsilt", "93", "https://www.aps.dz/media/k2/items/cache/5315ea0bd88e4821b9917d0cdeb4287a_M.jpg", false));
        list.add(new ItemsModel("Batna", "92", "https://airalgerie.dz/wp-content/uploads/2016/10/batna_780x360.jpg", false));
        list.add(new ItemsModel("Médéa", "92", "https://www.aps.dz/media/k2/items/cache/ced3fdcd2ecb959c55cc21b78e854f34_M.jpg", false));
        list.add(new ItemsModel("Oum El Bouaghi", "81", "https://i0.wp.com/harba-dz.com/wp-content/uploads/2020/10/Wilaya-dOum-El-Bouaghi.jpg?fit=1000%2C661&ssl=1", false));
        list.add(new ItemsModel("Sidi Bel Abbès", "66", "https://i.pinimg.com/564x/89/d9/73/89d973521543d7d97b1a1b3168de089d.jpg", false));
        list.add(new ItemsModel("M'Sila", "53", "https://www.interieur.gov.dz/images/djmediatools/bou-saada-m-sila2017.jpg", false));
        list.add(new ItemsModel("Saïda", "49", "https://previews.123rf.com/images/rpbmedia/rpbmedia1803/rpbmedia180300656/97671685-saida-08-juin-2017-centre-historique-de-saida-alg%C3%A9rie.jpg?fj=1", false));
        list.add(new ItemsModel("Tébessa", "46", "https://upload.wikimedia.org/wikipedia/commons/3/32/Porte_Caracalla_-_T%C3%A9bessa_%D8%A8%D8%A7%D8%A8_%D9%83%D8%B1%D9%83%D9%84%D8%A7_-_%D8%AA%D8%A8%D8%B3%D8%A9_3.jpg", false));
        list.add(new ItemsModel("Djelfa", "46", "https://www.aps.dz/media/k2/items/cache/46c7de1a7978890f73b9b9afe6352eee_M.jpg", false));
        list.add(new ItemsModel("Tiaret", "41", "https://upload.wikimedia.org/wikipedia/commons/3/3d/Tiaret_in_night.jpg", false));
        list.add(new ItemsModel("Khenchela", "40", "https://www.aps.dz/media/k2/items/cache/064672a746214359df982e54c0aa21c9_M.jpg", false));
        list.add(new ItemsModel("Biskra", "34", "https://aeroports-de-lyon.imgix.net/sites/default/files/2020-06/destination-biskra-header.jpg?fm=webp&ixlib=php-3.3.1&s=1cea3fd00a831b09bd15bf07424e83c0", false));
        list.add(new ItemsModel("El M'Ghair", "18,36", "https://www.aps.dz/media/k2/items/cache/a5c2f60ccab61113f7fb81ae4e28071b_M.jpg", false));
        list.add(new ItemsModel("Laghouat", "18", "https://airalgerie.dz/wp-content/uploads/2016/10/laghouat_374x374-1-374x362.jpg", false));
        list.add(new ItemsModel("Ouled Djellal", "15,26", "https://topdestinationsalgerie.com/wp-content/uploads/2021/06/Ouled-Djellal2.jpeg", false));
        list.add(new ItemsModel("Touggourt", "14,18", "https://airalgerie.dz/wp-content/uploads/2016/10/touggourt-780x360.jpg", false));
        list.add(new ItemsModel("Oued", "14", "https://www.aquaportail.com/pictures1301/oued-el-kebir.jpg", false));
        list.add(new ItemsModel("Naâma", "12", "https://i0.wp.com/harba-dz.com/wp-content/uploads/2020/10/Wilaya-de-Naama.jpg?fit=720%2C540&ssl=1", false));
        list.add(new ItemsModel("Ghardaïa", "6,5", "https://cdn.britannica.com/23/136123-050-EFA7DBA5/Ghardaia-Alg.jpg", false));
        list.add(new ItemsModel("El Bayadh", "4,2", "https://www.algerie360.com/wp-content/uploads/2018/07/el-beydh.jpg?x30148", false));
        list.add(new ItemsModel("Ouargla", "3,2", "https://www.certifer.fr/media/images/catalog/article/77/big/44.jpg", false));
        list.add(new ItemsModel("Timimoun", "2,6", "https://img.over-blog-kiwi.com/2/69/72/63/20180323/ob_202c64_file-64.png", false));
        list.add(new ItemsModel("Béchar", "1,87", "https://algeriecultures.com/wp-content/uploads/2021/03/Sans-titre-6-10.jpg", false));
        list.add(new ItemsModel("Adrar", "1,7", "https://topdestinationsalgerie.com/wp-content/uploads/2021/03/Charouine_Adrar.jpg", false));
        list.add(new ItemsModel("Meniaa", "0,94", "https://www.delcampe.net/static/img_large/auction/000/280/592/374_001.jpg?v=0", false));
        list.add(new ItemsModel("Béni Abbès", "0,92", "https://cdn.tourismetvoyages.dz/wp-content/uploads/2022/02/Beni-abbes.jpg", false));
        list.add(new ItemsModel("In Salah", "0,49", "https://airalgerie.dz/wp-content/uploads/2016/10/ain-salah-780x360.jpg", false));
        list.add(new ItemsModel("Tamanrasset", "0,38", "https://media.routard.com/image/43/4/photo.1413434.w630.jpg", false));
        list.add(new ItemsModel("Tindouf", "0,32", "https://radioalgerie.dz/news/sites/default/files/styles/282x211/public/tindouf-image.jpg?itok=n4sD4H_q", false));
        list.add(new ItemsModel("Djanet", "0,31", "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/11/e1/e5/69/ihrir-oasis-tassili-n.jpg?w=1200&h=-1&s=1", false));
        list.add(new ItemsModel("Illizi", "0,2", "https://i0.wp.com/harba-dz.com/wp-content/uploads/2020/10/Wilaya-dIllizi.jpg?fit=1000%2C667&ssl=1", false));
        list.add(new ItemsModel("Bordj Badji Mokhtar", "0,18", "https://mainsvertes.org/wp-content/uploads/2019/07/desert-sahara-Algerie.jpg", false));
        list.add(new ItemsModel("In Guezzam", "0,13", "https://www.aps.dz/media/k2/items/cache/d9411252949e433b340a354ab4fca7f5_M.jpg", false));

        return list;
    }

    public static ArrayList<Place_Model> AlgerList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Mémorial du Martyr", "123", "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRqEBeXxTYZJhKjkvZuZL2QWcditmfwzEhpuzUzMPE7siJOFPEPhrqTgqT9ZmWf44-ZdEtOh_LDIkghswXc8sAdww"));
        lis.add(new Place_Model("Basilique Notre-Dame d'Afrique", "123", "https://i.pinimg.com/originals/85/93/3f/85933f2c8f4364185684a4c5294f4595.jpg"));
        lis.add(new Place_Model("Jardin Botanique du Hamma - Jardin", "123", "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQqMRoposBmhK-Az7wquyV-UxALI-A_A-d1XMDgPwFJGeQpsLc4YBajRdD5zgOIsanbVKoc-Am6ulLVbmyP92hcjg"));
        lis.add(new Place_Model("Musée National du Bardo", "123", "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQNh22G2RSwohx0_0naLgsgWsyR7nSmxd74mj8leDsXMu0MqFo4mGPYCatX00sH08wp0yadAHxVd94kMAmUKjRtKA"));
        lis.add(new Place_Model("مسجد الجزائر الاعظم", "123", "https://encrypted-tbn3.gstatic.com/licensed-image?q=tbn:ANd9GcQbbQv-LDOuRs7JawREiAMEbEWGWpdPpTSzbiU_nUsjz2MaS0h3LLA4A7K36exDOSZ5bJ0qMOnGPmjlNLWK0WP_gA"));
        lis.add(new Place_Model("Musée des Beaux Arts", "123", "https://encrypted-tbn0.gstatic.com/licensed-image?q=tbn:ANd9GcQ_SSuBEmeaOuVoelem2NGxYq8ujA0GgWeYDKGk17SEh63eyCVlkD2yX9lG_CelSUeSTSdEkL1bPjrZuctLLwQrAg"));
        return lis;
    }

    public static ArrayList<Place_Model> OranList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Forteresse de Santa Cruz", "123", "https://encrypted-tbn2.gstatic.com/licensed-image?q=tbn:ANd9GcTQe7bozIPbSwlD2Dor6EwMMi3A9YCTPc1IvHuGSsqkWn1Tm59MoEsZUOad_-dyWqlXfe0qIBgjmkIr7b-l-vNhIw"));
        lis.add(new Place_Model("La coeur de ville oran", "123", "https://cdn.generationvoyage.fr/2019/01/ville-oran.jpg"));
        lis.add(new Place_Model("Arzew", "123", "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/10/5d/ac/f0/oran4.jpg?w=1000&h=600&s=1"));
        lis.add(new Place_Model("Cathédrale du Sacré-Cœur d'Oran", "123", "https://media-cdn.tripadvisor.com/media/photo-s/11/b1/e3/16/cathedral.jpg"));
        lis.add(new Place_Model("Boutlélis", "123", "https://upload.wikimedia.org/wikipedia/commons/f/ff/Mairie_de_Boutlelis.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> BlidaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Béni Mered", "123", "https://upload.wikimedia.org/wikipedia/commons/3/35/Beni_Mered_-_la_mairie_-_panoramio.jpg"));
        lis.add(new Place_Model("Chiffa", "123", "https://upload.wikimedia.org/wikipedia/commons/2/24/Chiffa_mountain.jpg"));
        lis.add(new Place_Model("Chréa", "123", "https://upload.wikimedia.org/wikipedia/commons/7/7f/Chr%C3%A9a_%D8%B4%D8%B1%D9%8A%D8%B9%D8%A9_-_panoramio_%284%29.jpg"));
        lis.add(new Place_Model("Ouled Yaïch District", "123", "https://scontent-frt3-2.xx.fbcdn.net/v/t1.6435-9/121003684_1666642280169580_1250516602306515425_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeFZVxnNpjLyM4ybll0SKIM7qAQdwBZelOCoBB3AFl6U4Fc-5aRgyGtEClB-P1_np7_OEAClJK-NaTGPu7Zaqore&_nc_ohc=BEpR5-XITnEAX9SnftK&_nc_ht=scontent-frt3-2.xx&oh=00_AT85Tlbd8RT05QAFP-IpwRouzeuLKAtdvNi4WE9uz8SNxA&oe=62B68245"));
        return lis;
    }

    public static ArrayList<Place_Model> BoumerdèsList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Ammal", "123", "https://upload.wikimedia.org/wikipedia/commons/b/bb/Ammal_-_Boumerdes_%D8%B9%D9%85%D8%A7%D9%84_-_%D8%A8%D9%88%D9%85%D8%B1%D8%AF%D8%A7%D8%B3_-_panoramio.jpg"));
        lis.add(new Place_Model("Baghlia", "123", "https://upload.wikimedia.org/wikipedia/commons/5/5f/Baghlia_rue_aibda_said.jpg"));
        lis.add(new Place_Model("Dellys", "123", "https://upload.wikimedia.org/wikipedia/commons/6/66/Dellys_-_Tadelles.jpg"));
        lis.add(new Place_Model("Tidjelabine", "123", "https://upload.wikimedia.org/wikipedia/commons/9/9c/Tidjelabine_%D8%AA%D9%8A%D8%AC%D9%84%D8%A7%D8%A8%D9%8A%D9%86_-_panoramio.jpg"));
        lis.add(new Place_Model("Thénia", "123", "https://upload.wikimedia.org/wikipedia/commons/9/92/Thenia_11092012.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> ConstantineList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("El Khroub", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c5/Tomb_of_Massinissa_01.jpg"));
        lis.add(new Place_Model("Aïn Abid", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0f/Ain_Abid.JPG"));
        lis.add(new Place_Model("Musée Cirta", "123", "https://encrypted-tbn1.gstatic.com/licensed-image?q=tbn:ANd9GcTrAtFh2Ol0o5WGNUDax1_iuvSMMsNgr4nrnZSSV0_zKFT3l8d3H-KqQIk1ByGMu7fzhtHfzPD3m9Jc70k6oZumYA"));
        lis.add(new Place_Model("Pont suspendu Sidi M'Cid", "123", "https://encrypted-tbn1.gstatic.com/licensed-image?q=tbn:ANd9GcS3R0IrupPjcM0KNrLdGDE4R69c_0vYsDipSu0E3COxc2UMGdH304dGt06Y62JgVpwfFU4yK-SmYC__25HtWety6Q"));
        lis.add(new Place_Model("Mosquée Emir Abdelkader", "123", "https://encrypted-tbn3.gstatic.com/licensed-image?q=tbn:ANd9GcQWRkuZp7SMZJVwqpzP83jL9-KBye4abaPmUtnUXZ1cXsQMp-ChMudV0iaIESSGpTUVP_5O86e5FqAgoaySGB1FgQ"));
        return lis;
    }

    public static ArrayList<Place_Model> AnnabaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Basilique « Saint Augustin »", "123", "https://encrypted-tbn1.gstatic.com/licensed-image?q=tbn:ANd9GcSF6w8B8yn8rbq3LWcB1fPljn1ZX9ZRkvBkLFAHdH9zayAOnlH_kxy2otpGPRQYatmf1UHfv2PaPvpXu3-qMh7RgA    "));
        lis.add(new Place_Model("Musée des Ruines d'Hyppone", "123", "https://lh5.googleusercontent.com/p/AF1QipP9RhkqSwuRLlbEzoytC7Tk2IRKObg3QeLLzjcn=w464-h260-n-k-no"));
        lis.add(new Place_Model("Parc Farouk Land", "123", "https://lh5.googleusercontent.com/p/AF1QipMTAhe4y3bP6K0wLPKKuLOimT_eljw3UBhU6gfJ=w464-h260-n-k-no"));
        lis.add(new Place_Model("Cap de Garde", "123", "https://encrypted-tbn2.gstatic.com/licensed-image?q=tbn:ANd9GcQKF8muTJ9rkT9gYHuR0VOYE3baOQAJUmVdKFd8_S5h4m2aSjytfIWgMVUlF_b1oCI8wp_IPI8Bf4B8Fb6Ekt0-CA"));
        lis.add(new Place_Model("Plage Gassiot", "123", "https://lh5.googleusercontent.com/p/AF1QipNJhULd_Jsh0SivLKriThnnEn6mASvSrkzKLHna=w464-h260-n-k-no"));
        return lis;
    }

    public static ArrayList<Place_Model> MostaganemList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("AZ Aquapark", "123", "https://lh5.googleusercontent.com/p/AF1QipNOa_kE3vjeW5glnlZkAT6R0noadzloJX6nzCdq=w464-h260-n-k-no"));
        lis.add(new Place_Model("Parc D'attraction", "123", "https://lh5.googleusercontent.com/p/AF1QipM4ME6_qxR_6FZF-yJg7bg3YffsF3HyaH-xKpS6=w464-h260-n-k-no"));
        lis.add(new Place_Model("Musée du Moudjahid", "123", "https://lh5.googleusercontent.com/p/AF1QipP0jDhquWqkEE-KomldTOJtmQoStqHy-ngm1TY=w464-h260-n-k-no"));
        lis.add(new Place_Model("Djebel Chaïbia", "123", "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRPy6laT7LpSMVu46qcvwa8NVHvbJpnsWAK5J9FDOH4RueQNS7gEk9Iy5sj-_nsRV0VTn9bJCbQ3IzhoA"));
        lis.add(new Place_Model("Mostaland", "123", "https://scontent-vie1-1.xx.fbcdn.net/v/t1.6435-9/78433528_741765909635072_5759419554727985152_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=e3f864&_nc_ohc=hjXwqmkTMbQAX9sJg_P&_nc_ht=scontent-vie1-1.xx&oh=00_AT_0byI9c0fJqsb3iHmDcpMsfwUKqLpMDP07Pk8WyZUy5A&oe=62B24D9F"));
        return lis;
    }

    public static ArrayList<Place_Model> Tizi_OuzouList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Draâ El Mizan", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b4/Draa_El_Mizan.jpg"));
        lis.add(new Place_Model("Yattafène", "123", "https://upload.wikimedia.org/wikipedia/commons/2/20/Ait_Daoud%2C_Tizi_Ouzou%2C_Algeria.jpg"));
        lis.add(new Place_Model("Aghrib", "123", "https://upload.wikimedia.org/wikipedia/commons/6/62/Aghribs_view.JPG"));
        lis.add(new Place_Model("Aït Mahmoud", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c6/Taguemount_Azouz_Rachid_ath_said.jpg"));
        lis.add(new Place_Model("Azeffoun   ", "123", "https://upload.wikimedia.org/wikipedia/commons/1/10/Plage_Sidi_Khlifa.JPG"));
        return lis;
    }

    public static ArrayList<Place_Model> BéjaïaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Draâ El-Kaïd", "123", "https://upload.wikimedia.org/wikipedia/commons/0/06/Commune_de_Draa_El_Ga%C3%AFd_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%B0%D8%B1%D8%A7%D8%B9_%D8%A7%D9%84%D9%82%D8%A7%D9%8A%D8%AF_-_panoramio.jpg"));
        lis.add(new Place_Model("Ighram", "123", "https://upload.wikimedia.org/wikipedia/commons/8/8e/Ighrem_%D8%A7%D8%BA%D8%B1%D8%A7%D9%85.jpg"));
        lis.add(new Place_Model("Tifra", "123", "https://upload.wikimedia.org/wikipedia/commons/8/82/Tifra.jpg"));
        lis.add(new Place_Model("El Kseur", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b1/Mairie_EL_Kseur.jpg"));
        lis.add(new Place_Model("Tala Hamza", "123", "https://upload.wikimedia.org/wikipedia/commons/8/85/Mairie_de_Tala_Hamza.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TipazaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bouharoun", "123", "https://upload.wikimedia.org/wikipedia/commons/3/3f/Bou_Haroun.jpg"));
        lis.add(new Place_Model("Damous", "123", "https://upload.wikimedia.org/wikipedia/commons/2/2b/Damous.JPG"));
        lis.add(new Place_Model("Hadjout", "123", "https://upload.wikimedia.org/wikipedia/commons/4/48/Centre_de_la_ville.jpg"));
        lis.add(new Place_Model("Koléa", "123", "https://upload.wikimedia.org/wikipedia/commons/2/22/Kol%C3%A9a_-_la_mairie_%D8%AF%D8%A7%D8%B1_%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_-_%D8%A7%D9%84%D9%82%D9%84%D9%8A%D8%B9%D8%A9_-_panoramio.jpg"));
        lis.add(new Place_Model("Sidi Semiane", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6e/Le_Mausol%C3%A9_de_Sidi_Semiane.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> JijelList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Cap carbon", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c7/Cap_carbon_B%C3%A9jaia.jpg"));
        lis.add(new Place_Model("Ziama Mansouriah", "123", "https://upload.wikimedia.org/wikipedia/commons/8/84/Vue_sur_ziama_mansouria_port_et_village.jpg"));
        lis.add(new Place_Model("Houma Keramane", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4b/Houma_Keramane%2C_B%C3%A9ja%C3%AFa.jpg"));
        lis.add(new Place_Model("Djimla", "123", "https://upload.wikimedia.org/wikipedia/commons/d/dc/Djimla000.JPG"));
        lis.add(new Place_Model("Les Aiguades", "123", "https://upload.wikimedia.org/wikipedia/commons/4/45/Les_Aiguades.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> SétifList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("ترامواي سطيف", "123", "https://upload.wikimedia.org/wikipedia/commons/6/61/%D8%AA%D8%B1%D8%A7%D9%85%D9%88%D8%A7%D9%8A_%D8%B3%D8%B7%D9%8A%D9%81.jpg"));
        lis.add(new Place_Model("AIN ELFOUARRA", "123", "https://upload.wikimedia.org/wikipedia/commons/7/75/Le_monument_historique_de_SETIF%2CAIN-ELFOUARRA_sous_la_neige_4_-_panoramio.jpg"));
        lis.add(new Place_Model("Setif Park Mal", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4c/Setif_-_Park_Mall_%D8%B3%D8%B7%D9%8A%D9%81_-_%D8%A8%D8%A7%D8%B1%D9%83_%D9%85%D9%88%D9%84_-_panoramio_-_habib_kaki.jpg"));
        lis.add(new Place_Model("حديقة التسلية بسطيف", "123", "https://upload.wikimedia.org/wikipedia/commons/5/5b/Setif_-_parc_d%27attraction_%D8%AD%D8%AF%D9%8A%D9%82%D8%A9_%D8%A7%D9%84%D8%AA%D8%B3%D9%84%D9%8A%D8%A9_%D8%A8%D8%B3%D8%B7%D9%8A%D9%81_-_panoramio.jpg"));
        lis.add(new Place_Model("Stade 8 Mai 1945", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c9/Stade_8_Mai_1945_%28vue_a%C3%A9rienne%29.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> SkikdaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Eraguene", "123", "https://upload.wikimedia.org/wikipedia/commons/e/ed/Barrage_d%27Erraguene_%283%29_%3B_wilaya_de_Jijel_%3B_Alg%C3%A9rie.jpg"));
        lis.add(new Place_Model("Bekkouche Lakhdar", "123", "https://upload.wikimedia.org/wikipedia/commons/e/e2/Villagegastucopyjanv07.jpg"));
        lis.add(new Place_Model("Collo", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c3/Collo_skikda.jpg"));
        lis.add(new Place_Model("Filfla", "123", "https://upload.wikimedia.org/wikipedia/commons/9/96/Plage_de_Filfila%2C_Skikda_%28Alg%C3%A9rie%29.jpg"));
        lis.add(new Place_Model("Tamalous", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f1/Tamalous.JPG"));
        return lis;
    }

    public static ArrayList<Place_Model> MilaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Ahmed Rachedi", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c0/Ahmed_Rachedi_Mila_Algerie_2012.jpg"));
        lis.add(new Place_Model("Aïn Beida Harriche", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a3/A%C3%AFn_Beida_Harriche_Wilaya_de_Mila_Alg%C3%A9rie_2013.jpg"));
        lis.add(new Place_Model("Chelghoum Laïd", "123", "https://upload.wikimedia.org/wikipedia/commons/5/56/Chelghoum_Laid.JPG"));
        lis.add(new Place_Model("Chigara", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f6/Chigara_Wilaya_de_Mila_Alg%C3%A9rie_2013.jpg"));
        lis.add(new Place_Model("Elayadi Barbes", "123", "https://upload.wikimedia.org/wikipedia/commons/3/37/AYADI_BERBES.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> ChlefList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Oued Fodda", "123", "https://upload.wikimedia.org/wikipedia/commons/4/47/Pont_Baarge_de_Oued_Fooda.jpg"));
        lis.add(new Place_Model("Tadjena", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4e/Tadjena_%28le_11-05-2007%29.jpg"));
        lis.add(new Place_Model("Talassa", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0a/Vieux_olivier_au_montagne_pr%C3%A8s_de_Talassa_Chlef_Alg%C3%A9rie.jpg"));
        lis.add(new Place_Model("Oued Gousine", "123", "https://upload.wikimedia.org/wikipedia/commons/5/50/Village_de_Oued_Goussine.jpg"));
        lis.add(new Place_Model("Harchoun", "123", "https://upload.wikimedia.org/wikipedia/commons/d/d0/Harchoun_%D8%AD%D8%B1%D8%B4%D9%88%D9%86.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Bordj_Bou_ArreridjList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bordj Zemoura", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6c/Bordj_Zemoura_-_Algeria_%282020%29.jpg"));
        lis.add(new Place_Model("TEFREG", "123", "https://scontent.forn3-2.fna.fbcdn.net/v/t1.6435-9/38614755_2158672814206713_3840440871388446720_n.png?_nc_cat=107&ccb=1-7&_nc_sid=730e14&_nc_ohc=eHYPpdS_kXoAX_ppQRn&_nc_ht=scontent.forn3-2.fna&oh=00_AT_3z4YLigmE91DUx2xqseB2Qkvea3-mMTrymie1JUKbDg&oe=62B28D09"));
        lis.add(new Place_Model("Colla", "123", "https://upload.wikimedia.org/wikipedia/commons/b/ba/JAAFRA.png"));
        lis.add(new Place_Model("Cour El Wiam", "123", "https://www.vitaminedz.com/photos/92/92232-cour-el-wiam-au-centre-ville-de-bordj-bou-arreridj.jpg"));
        lis.add(new Place_Model("Mosquée de Guenzat", "123", "https://pbs.twimg.com/media/Ea3FWXmWAAAbvJB.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> BouiraList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bouïra", "123", "https://upload.wikimedia.org/wikipedia/commons/e/e5/BOUIRA.jpg"));
        lis.add(new Place_Model("Ahl El Ksar", "123", "https://upload.wikimedia.org/wikipedia/commons/8/83/Ahl_El_Ksar%2C_Wilaya_de_Bouira%2C_Alg%C3%A9rie.jpg"));
        lis.add(new Place_Model("Aïn Turk", "123", "https://upload.wikimedia.org/wikipedia/commons/1/1c/A_highway_bridge_near_A%C3%AFn_Turk%2C_Algeria_02966.jpg"));
        lis.add(new Place_Model("Bechloul", "123", "https://upload.wikimedia.org/wikipedia/commons/8/81/Bechloul_%D8%A8%D8%B4%D9%84%D9%88%D9%84_-_panoramio.jpg"));
        lis.add(new Place_Model("Kadiria", "123", "https://upload.wikimedia.org/wikipedia/commons/7/76/CENTRE_VILLE_KADIRIA.JPG"));
        return lis;
    }

    public static ArrayList<Place_Model> Aïn_DeflaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Defla", "123", "https://upload.wikimedia.org/wikipedia/commons/2/28/Ain_Defla_%D8%B9%D9%8A%D9%86_%D8%A7%D9%84%D8%AF%D9%81%D9%84%D8%A9_-_panoramio_%286%29.jpg"));
        lis.add(new Place_Model("Arib", "123", "https://upload.wikimedia.org/wikipedia/commons/7/75/AinDefla_arib.jpg"));
        lis.add(new Place_Model("Djendel", "123", "https://upload.wikimedia.org/wikipedia/commons/1/19/Djendel_%D8%AC%D9%86%D8%AF%D9%84_-_panoramio.jpg"));
        lis.add(new Place_Model("El Attaf", "123", "https://upload.wikimedia.org/wikipedia/commons/e/e2/El_Attaf_-_Bonne_route_%D8%A7%D9%84%D8%B9%D8%B7%D8%A7%D9%81_-_panoramio.jpg"));
        lis.add(new Place_Model("Khemis Miliana", "123", "https://upload.wikimedia.org/wikipedia/commons/5/5a/Mosqu%C3%A9e_El-Atike_Khemis_Miliana.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Aïn_TémouchentList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Béni Saf", "123", "https://upload.wikimedia.org/wikipedia/commons/d/d4/Lettres_sur_la_ville_de_Beni-Saf%2C_Alg%C3%A9rie._DZ.JPG"));
        lis.add(new Place_Model("Aïn El Arbaa", "123", "https://scontent.forn3-2.fna.fbcdn.net/v/t1.6435-9/126265002_103306924942898_3302592876510161721_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=e3f864&_nc_ohc=HKN77nTL4X8AX8gtE4j&_nc_ht=scontent.forn3-2.fna&oh=00_AT_Y4MrpVwi1BuMXYtgeUMW9NeurB7aJC5mhSQXyIKq0RQ&oe=62B27901"));
        lis.add(new Place_Model("Chaabet El Ham", "123", "https://fr-academic.com/pictures/frwiki/67/Chaabat2.JPG"));
        lis.add(new Place_Model("Oued Berkeche", "123", "https://upload.wikimedia.org/wikipedia/commons/7/70/Ain_Temouchent_%D8%B9%D9%8A%D9%86_%D8%AA%D9%8A%D9%85%D9%88%D8%B4%D9%86%D8%AA_-_panoramio_%283%29.jpg"));
        lis.add(new Place_Model("Sidi Ben Adda", "123", "https://i0.wp.com/www.lnr-dz.com/wp-content/uploads/2020/11/Sidi-Ben-Adda.jpg?w=500&ssl=1"));
        return lis;
    }

    public static ArrayList<Place_Model> RelizaneList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Oued Rhiou", "123", "https://i0.wp.com/www.lnr-dz.com/wp-content/uploads/2020/12/Relizane.jpg?w=500&ssl=1"));
        lis.add(new Place_Model("Bendaoud", "123", "https://upload.wikimedia.org/wikipedia/commons/8/8f/Bendaoud_%D8%A8%D9%86_%D8%AF%D8%A7%D9%88%D8%AF_-_panoramio.jpg"));
        lis.add(new Place_Model("El Hamadna", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b0/El_Hamadna.jpg"));
        lis.add(new Place_Model("Relizane", "123", "https://www.aps.dz/media/k2/items/cache/fe78da8b103ad10f2706b238ddbb1306_M.jpg"));
        lis.add(new Place_Model("Zemmoura", "123", "https://upload.wikimedia.org/wikipedia/commons/8/8c/Gare_de_Zemmora_avant_1962.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> MascaraList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Mascara, Algeria", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f7/Ville_de_Mascara_%D9%85%D8%AF%D9%8A%D9%86%D8%A9_%D9%85%D8%B9%D8%B3%D9%83%D8%B1_-_panoramio_%281%29.jpg"));
        lis.add(new Place_Model("Bou Hanifia", "123", "https://upload.wikimedia.org/wikipedia/commons/7/74/Bouhnifia_%D8%A8%D9%88%D8%AD%D9%86%D9%8A%D9%81%D9%8A%D8%A9.jpg"));
        lis.add(new Place_Model("El-Gaada", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f5/Mairie_d%27El_Gaada.jpg"));
        lis.add(new Place_Model("Ghriss", "123", "https://upload.wikimedia.org/wikipedia/commons/2/2f/Ghriss_%D8%BA%D8%B1%D9%8A%D8%B3_-_panoramio_%282%29.jpg"));
        lis.add(new Place_Model("Zahana", "123", "https://upload.wikimedia.org/wikipedia/commons/5/5f/Mairie_de_Zahana.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> El_TarfList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("lac des oiseaux", "123", "https://www.algerie360.com/wp-content/uploads/2014/02/plus-de-30-000-oiseaux-deau-denombres-a-el-tarf.jpg"));
        lis.add(new Place_Model("Lac Tonga", "123", "https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/%D8%BA%D8%A7%D8%A8%D8%A9_%D8%A8%D8%AD%D9%8A%D8%B1%D8%A9_%22%D8%B7%D9%88%D9%86%D9%82%D8%A9%22.jpg/1200px-%D8%BA%D8%A7%D8%A8%D8%A9_%D8%A8%D8%AD%D9%8A%D8%B1%D8%A9_%22%D8%B7%D9%88%D9%86%D9%82%D8%A9%22.jpg"));
        lis.add(new Place_Model("Bougous", "123", "https://scontent.faae2-2.fna.fbcdn.net/v/t39.30808-6/268420128_765490771520223_8093392141306968920_n.jpg?_nc_cat=111&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=NuydN0NCssIAX_TRWz4&_nc_oc=AQnq2Iuv82e9SFXmtPoCLSAGU9P1xvuDRdcLkCr7ZUermFc5QIc5LR34b0B6-JzOcSE&_nc_ht=scontent.faae2-2.fna&oh=00_AT8WnIFDkXBE8J7fY0QKIDJxKT6ctTPvYXst2LkdYyVCSg&oe=62B41910"));
        lis.add(new Place_Model("el kala ", "123", "https://i.pinimg.com/originals/65/20/5e/65205e15525c3335712ea4040e6a3e8d.jpg"));
        lis.add(new Place_Model("Oued Zitoun", "123", "https://upload.wikimedia.org/wikipedia/commons/7/78/Oued_Zitoun_Ghezala_Tunisie.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> GuelmaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Makhlouf", "123", "https://upload.wikimedia.org/wikipedia/commons/7/7c/%D8%B3%D8%AF_%D9%85%D8%AC%D8%A7%D8%B2_%D8%A7%D9%84%D8%A8%D9%82%D8%B1.jpg"));
        lis.add(new Place_Model("Hammam Debagh", "123", "https://upload.wikimedia.org/wikipedia/commons/2/24/Hammam_Debagh_%D8%AD%D9%85%D8%A7%D9%85_%D8%AF%D8%A8%D8%A7%D8%BA_02.jpg"));
        lis.add(new Place_Model("Héliopolis", "123", "https://upload.wikimedia.org/wikipedia/commons/e/e5/H%C3%A9liopolis.jpeg"));
        lis.add(new Place_Model("Medjez Amar", "123", "https://upload.wikimedia.org/wikipedia/commons/f/fb/GM_Seybouse01.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TelemcenList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Nedroma", "123", "https://lechodalgerie-dz.com/wp-content/uploads/2019/06/p-14-1-3.jpg"));
        lis.add(new Place_Model("Ghazaouet", "123", "https://www.vitaminedz.com/photos/229/229514-tlemcen-ghazaouet-dar-yaghmoracen.jpg"));
        lis.add(new Place_Model("Lalla Setti", "123", "https://journals.openedition.org/etudescaribeennes/docannexe/image/12450/img-9-small580.jpg"));
        lis.add(new Place_Model("Cascades d’El Ourit", "123", "https://journals.openedition.org/etudescaribeennes/docannexe/image/12450/img-7.jpg"));
        lis.add(new Place_Model("Grottes de Beni-Add", "123", "https://journals.openedition.org/etudescaribeennes/docannexe/image/12450/img-8-small580.jpg"));
        lis.add(new Place_Model("Mansourah", "123", "https://journals.openedition.org/etudescaribeennes/docannexe/image/12450/img-11-small580.jpg"));
        lis.add(new Place_Model("Barbajani", "123", "https://scontent-vie1-1.xx.fbcdn.net/v/t1.6435-9/36454479_709206579440430_2937705704309391360_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=730e14&_nc_ohc=4LIoRRczWckAX8akF_3&_nc_ht=scontent-vie1-1.xx&oh=00_AT8QfmPbJwrkcG2JV1zwwxxiED8ae_go23CHwLlxvfD6fA&oe=62B4C6C7"));
        lis.add(new Place_Model("Moscarda port say", "123", "https://media.routard.com/image/89/0/pt27539.1238890.w430.jpg"));
        lis.add(new Place_Model("Sidi youchaa", "123", "https://scontent-vie1-1.xx.fbcdn.net/v/t1.6435-9/200394482_4122074234516483_6816946400388948031_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=zVgbjeHt-BoAX-tyYWy&_nc_ht=scontent-vie1-1.xx&oh=00_AT9B_9hxNYQ2GfKzjIX8QEumQub8-A8h-JzOoNsAJ7nvPw&oe=62B2D8EE"));
        return lis;
    }

    public static ArrayList<Place_Model> Souk_AhrasList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Khemissa", "123", "https://upload.wikimedia.org/wikipedia/commons/7/73/GM_Khamissa_Roman_Theatre01.jpg"));
        lis.add(new Place_Model("Sedrata", "123", "https://upload.wikimedia.org/wikipedia/commons/d/db/Sedrata.jpg"));
        lis.add(new Place_Model("Hanancha", "123", "https://upload.wikimedia.org/wikipedia/commons/d/dc/Souk-ahras_barage.jpg"));
        lis.add(new Place_Model("Mechroha", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f7/Souk_Ahras%2C_Algeria.jpg"));
        lis.add(new Place_Model("Ain Soltane", "123", "https://upload.wikimedia.org/wikipedia/commons/4/41/Ain_Soltan.jpg"));
        lis.add(new Place_Model("Ouled Driss", "123", "https://www.vitaminedz.com/photos/94/94815-les-montagnes-de-ouled-driss.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TissemsiltList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Beni Chaib", "123", "https://upload.wikimedia.org/wikipedia/commons/0/00/%D8%A8%D8%AD%D9%8A%D8%B1%D8%A9_%D8%A8%D9%86%D9%8A_%D8%B4%D8%B9%D9%8A%D8%A8.jpg"));
        lis.add(new Place_Model("Bordj El Emir Abdelkader", "123", "https://upload.wikimedia.org/wikipedia/commons/a/aa/Bordj_Emir_Abdelkader_%D8%A8%D8%B1%D8%AC_%D8%A7%D9%84%D8%A7%D9%85%D9%8A%D8%B1_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D9%82%D8%A7%D8%AF%D8%B1.jpg"));
        lis.add(new Place_Model("Tissemsilt", "123", "https://upload.wikimedia.org/wikipedia/commons/0/00/Tissemsilt_%D8%AA%D9%8A%D8%B3%D9%85%D8%B3%D9%8A%D9%84%D8%AA_-_panoramio_%286%29.jpg"));
        lis.add(new Place_Model("Tamalaht", "123", "https://upload.wikimedia.org/wikipedia/commons/b/bc/Ouarsenis_2012%2C_Wilaya_de_Tissemsilt_%28Alg%C3%A9rie%29.jpg"));
        lis.add(new Place_Model("Youssoufia", "123", "https://upload.wikimedia.org/wikipedia/commons/9/96/Youssoufia_%D8%A7%D9%84%D9%8A%D9%88%D8%B3%D9%81%D9%8A%D8%A9_-_panoramio.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> BatnaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Touta", "123", "https://upload.wikimedia.org/wikipedia/commons/e/e7/A%C3%AFn_Touta.JPG"));
        lis.add(new Place_Model("Arris", "123", "https://upload.wikimedia.org/wikipedia/commons/c/cf/6527-vue-sur-le-pont-de-arris.jpg"));
        lis.add(new Place_Model("Inoughissen", "123", "https://upload.wikimedia.org/wikipedia/commons/1/16/Cap_B%C3%A9ar_Inoughissen_Batna_Algeria.jpg"));
        lis.add(new Place_Model("Menaâ", "123", "https://upload.wikimedia.org/wikipedia/commons/b/be/Le_village_de_Men%C3%A2a%2C_3_%28Wilaya_de_Batna%29.jpg"));
        lis.add(new Place_Model("Merouana", "123", "https://upload.wikimedia.org/wikipedia/commons/1/1a/Merouana.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> MédéaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Djouab", "123", "https://upload.wikimedia.org/wikipedia/commons/d/da/Djouab_%D8%AC%D9%88%D8%A7%D8%A8_-_panoramio.jpg"));
        lis.add(new Place_Model("Aïn Boucif", "123", "https://upload.wikimedia.org/wikipedia/commons/d/dd/Ain_Boucif_%D8%B9%D9%8A%D9%86_%D8%A8%D9%88%D8%B3%D9%8A%D9%81_-_panoramio_%282%29.jpg"));
        lis.add(new Place_Model("Sebt Aziz", "123", "https://upload.wikimedia.org/wikipedia/commons/d/d3/APC_de_Aziz_%D9%85%D9%82%D8%B1_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%B9%D8%B2%D9%8A%D8%B2_-_panoramio.jpg"));
        lis.add(new Place_Model("El Hamdania", "123", "https://upload.wikimedia.org/wikipedia/commons/5/5b/El_Hamdania_%D8%A7%D9%84%D8%AD%D9%85%D8%AF%D8%A7%D9%86%D9%8A%D8%A9_5.jpg"));
        lis.add(new Place_Model("Bouchrahil", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6a/Bouchrahil.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Oum_El_ouaghiList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Beïda", "123", "https://upload.wikimedia.org/wikipedia/commons/5/53/%D8%B9%D9%8A%D9%86_%D8%A7%D9%84%D8%A8%D9%8A%D8%B6%D8%A7%D8%A1_1.JPG"));
        lis.add(new Place_Model("Berriche", "123", "https://upload.wikimedia.org/wikipedia/commons/4/44/Commune_de_Berriche_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%A8%D8%B1%D9%8A%D8%B4.jpg"));
        lis.add(new Place_Model("Meskiana", "123", "https://upload.wikimedia.org/wikipedia/commons/b/bd/Meskiana_%D9%85%D8%B3%D9%83%D9%8A%D8%A7%D9%86%D8%A9.jpg"));
        lis.add(new Place_Model("Ksar Sbahi", "123", "https://upload.wikimedia.org/wikipedia/commons/d/dc/Les_hautes_plaines_sous_la_neige1.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Sidi_Bel_AbbèsList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Ben Badis", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b8/Ben_badis_3_in_2005.png"));
        // lis.add(new Place_Model("Dhaya","123","https://upload.wikimedia.org/wikipedia/commons/f/f9/Panorama_-_Dhaya_%D8%A7%D9%84%D8%B6%D8%A7%D9%8A%D8%A9_-_panoramio.jpg"));
        lis.add(new Place_Model("Mezaourou", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4d/Mairie_de_mezaourou.jpg"));
        lis.add(new Place_Model("Tessala", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0d/Tessala_atouche.jpg"));
        lis.add(new Place_Model("Sidi Brahim", "123", "https://upload.wikimedia.org/wikipedia/commons/d/d3/Sidi_Brahim_%28Sidi_Bel_Abb%C3%A8s%2C_Alg%C3%A9rie%29.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> MSilaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn El Hadjel", "123", "https://upload.wikimedia.org/wikipedia/commons/2/2b/Ain_el_Hadjel.JPG"));
        lis.add(new Place_Model("Bou Saâda", "123", "https://upload.wikimedia.org/wikipedia/commons/f/fe/Bousaayel.jpg"));
        lis.add(new Place_Model("Khettouti Sed El Djir", "123", "https://upload.wikimedia.org/wikipedia/commons/7/73/Khattouti_Sed_El_Djir_%D8%AE%D8%B7%D9%88%D8%B7%D9%8A_%D8%B3%D8%AF_%D8%A7%D9%84%D8%AC%D9%8A%D8%B1.jpg"));
        lis.add(new Place_Model("Maadid Brahim", "123", "https://upload.wikimedia.org/wikipedia/commons/7/76/Maadid.jpg"));
        lis.add(new Place_Model("El Hamel", "123", "https://upload.wikimedia.org/wikipedia/commons/7/76/El_Hamel.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> SaïdaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("El Hassasna", "123", "https://upload.wikimedia.org/wikipedia/commons/d/d3/El_Hassasna_%D8%A7%D9%84%D8%AD%D8%B3%D8%A7%D8%B3%D9%86%D8%A9_%2849065417096%29.jpg"));
        lis.add(new Place_Model("Saïda", "123", "https://upload.wikimedia.org/wikipedia/commons/7/77/SAIDA.jpg"));
        lis.add(new Place_Model("Sidi Amar", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b6/Sidi_Amar_%D9%85%D8%B3%D8%AC%D8%AF_%D8%B9%D9%85%D8%B1%D9%88_%D8%A8%D9%86_%D8%A7%D9%84%D8%B9%D8%A7%D8%B5_-_%D8%B3%D9%8A%D8%AF%D9%8A_%D8%A7%D8%B9%D9%85%D8%B1_-_panoramio.jpg"));
        lis.add(new Place_Model("Maadid Brahim", "123", "https://upload.wikimedia.org/wikipedia/commons/7/76/Maadid.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TébessaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Tébessa", "123", "https://upload.wikimedia.org/wikipedia/commons/d/da/T%C3%A9bessa-Porte_Caracala.jpg"));
        lis.add(new Place_Model("Negrine", "123", "https://upload.wikimedia.org/wikipedia/commons/6/62/Paysage_des_Nemenchas.1.jpg"));
        lis.add(new Place_Model("Saïda", "123", "https://upload.wikimedia.org/wikipedia/commons/7/77/SAIDA.jpg"));
        lis.add(new Place_Model("Centre ville", "123", "https://www.aps.dz/media/k2/items/cache/9ebe9fb33a8482578f11d56a7c60b3fd_M.jpg"));
        lis.add(new Place_Model("Ouenza", "123", "https://upload.wikimedia.org/wikipedia/commons/4/42/Ouenza_Station.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> DjelfaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Oussera", "123", "https://upload.wikimedia.org/wikipedia/commons/e/ee/Ain_Oussera_%D8%B9%D9%8A%D9%86_%D9%88%D8%B3%D8%A7%D8%B1%D8%A9_-_panoramio_%281%29.jpg"));
        lis.add(new Place_Model("Amourah", "123", "https://upload.wikimedia.org/wikipedia/commons/7/7d/Amoura_%D8%B9%D9%85%D9%88%D8%B1%D8%A9.jpg"));
        lis.add(new Place_Model("Birine", "123", "https://upload.wikimedia.org/wikipedia/commons/9/90/%D9%85%D8%B3%D8%AC%D8%AF_%D8%B9%D8%A8%D8%AF_%D8%A7%D9%84%D8%AD%D9%81%D9%8A%D8%B8_%D8%A7%D9%84%D9%82%D8%A7%D8%B3%D9%85%D9%8A_%D9%88%D8%B3%D8%A7%D8%AD%D8%A9_%D8%A3%D9%88%D9%84_%D9%86%D9%88%D9%81%D9%85%D8%A8%D8%B1_%D8%A7%D9%84%D8%A8%D9%8A%D8%B1%D9%8A%D9%86.jpg"));
        lis.add(new Place_Model("Aïn El Ibel", "123", "https://www.vitaminedz.com/photos/78/78356-souce-d-eau-ain-cherchara-dans-la-commune-de-ain-el.jpg"));
        lis.add(new Place_Model("Hassi Bahbah", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0c/Hassi_Bahbah%2C_Djelfa_Province_%28Algeria%29.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TiaretList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Zarit", "123", "https://upload.wikimedia.org/wikipedia/commons/1/10/%D8%AD%D8%AF%D9%8A%D9%82%D8%A9_%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D9%84%D8%B9%D9%8A%D9%86_%D8%B2%D8%A7%D8%B1%D9%8A%D8%AA_%D8%AA%D9%8A%D8%A7%D8%B1%D8%AA.JPG "));
        lis.add(new Place_Model("Tiaret", "123", "https://upload.wikimedia.org/wikipedia/commons/3/3d/Tiaret_in_night.jpg"));
        //lis.add(new Place_Model("Ain bouchekif","123","https://www.aps.dz/media/k2/items/cache/3003734d410ee512f162cc5cafbc7329_M.jpg"));
        lis.add(new Place_Model("Aïn Kermes", "123", "https://2.bp.blogspot.com/-jaF53igy2kY/V9s8royL65I/AAAAAAAACvw/edsubc-YuecxlisgYOIU2jUT64DYmCUSgCLcB/s1600/AIN%2BKERMES%2B214.JPG"));
        lis.add(new Place_Model("Bougara", "123", "https://scontent-ams4-1.xx.fbcdn.net/v/t39.30808-6/229839804_3018715135061659_6233973619509022913_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=8631f5&_nc_ohc=8nvKwCQTsoUAX-WgXVR&_nc_ht=scontent-ams4-1.xx&oh=00_AT-LTyK_35SS_4O_ESAftBD53IChxaEw3GqKG_Rm_Gvc5Q&oe=629432E9"));
        return lis;
    }

    public static ArrayList<Place_Model> KhenchelaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Ain touila", "123", "https://www.vitaminedz.com/photos/56/56359-ruines-a-ain-touila-wilaya-de-khenchla.jpg"));
        lis.add(new Place_Model("Babar", "123", "https://www.vitaminedz.com/photos/56/56423-la-commune-de-babar-a-khenchela.jpg"));
        lis.add(new Place_Model("M'Toussa", "123", "https://i.pinimg.com/564x/3f/bc/da/3fbcda6b0ff7ffec3f0d04c6a0cd780e.jpg"));
        lis.add(new Place_Model("Cherchar", "123", "https://scontent-ams4-1.xx.fbcdn.net/v/t1.6435-9/130310048_101497951833254_252257014820407154_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=s0MXdKoW35kAX9JQ4Ze&_nc_ht=scontent-ams4-1.xx&oh=00_AT8DpfYVEIuvoSweV3SbsjgOfN-joALp3FWuryjEAwrKNQ&oe=62B58814"));
        lis.add(new Place_Model("Ensigha", "123", "https://www.vitaminedz.com/photos/94/94623-les-palmiers-d-el-ouldja.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> BiskralaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Chetma", "123", "https://upload.wikimedia.org/wikipedia/commons/3/3a/Chetma_-_Biskra_%D8%B4%D8%AA%D9%85%D8%A9_-_%D8%A8%D8%B3%D9%83%D8%B1%D8%A9_-_panoramio.jpg"));
        lis.add(new Place_Model("Doucen", "123", "https://thumbs.dreamstime.com/z/oasis-de-doucen-88282422.jpg"));
        lis.add(new Place_Model("El Outaya", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f8/El_Outaya.JPG"));
        lis.add(new Place_Model("El Kantara", "123", "https://upload.wikimedia.org/wikipedia/commons/2/2f/Le_d%C3%A9fil%C3%A9_d%27el_Kantara.JPG"));
        lis.add(new Place_Model("Tolga", "123", "https://upload.wikimedia.org/wikipedia/commons/c/cb/FROBENIUS%281911%29_Tafel47_Speicherturm_in_Tolga%2C_am_Nordrand_dsr_Sahara.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> MghirList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Still", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0e/Still.JPG"));
        lis.add(new Place_Model("El Mghair", "123", "https://www.vitaminedz.com/photos/231/231043-zaouia-et-mausolee-el-hachemi-cherif.jpg"));
        lis.add(new Place_Model("Centre ville d'El Mghair", "123", "https://www.vitaminedz.com/photos/94/94403-le-centre-ville-d-el-mghair.jpg"));
        lis.add(new Place_Model("l'Entrée d'El Mghair", "123", "https://www.vitaminedz.com/photos/94/94417-a-l-entree-d-el-mghair.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> LaghouatList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Oued Morra", "123", "https://upload.wikimedia.org/wikipedia/commons/6/67/El_djedar_-_Oued_Morra_%D8%A7%D9%84%D8%AC%D8%AF%D8%B1_-_%D9%88%D8%A7%D8%AF_%D9%85%D8%B1%D8%A9.jpg"));
        lis.add(new Place_Model("Aflou", "123", "https://upload.wikimedia.org/wikipedia/commons/1/1b/Aflou_-_mosqu%C3%A9e_Imam_Muslim_%D8%A7%D9%81%D9%84%D9%88_-_%D9%85%D8%B3%D8%AC%D8%AF_%D8%A7%D9%84%D8%A7%D9%85%D8%A7%D9%85_%D9%85%D8%B3%D9%84%D9%85.jpg"));
        lis.add(new Place_Model("Aïn Madhi", "123", "https://upload.wikimedia.org/wikipedia/commons/d/de/Ain_Madhi_%D8%B9%D9%8A%D9%86_%D9%85%D8%A7%D8%B6%D9%8A_-_panoramio.jpg"));
        lis.add(new Place_Model("Sidi Makhlouf", "123", "https://upload.wikimedia.org/wikipedia/commons/4/48/Sidi_Makhlouf_%D8%B3%D9%8A%D8%AF%D9%8A_%D9%85%D8%AE%D9%84%D9%88%D9%81_-_panoramio_%281%29.jpg"));
        lis.add(new Place_Model("El Ghicha", "123", "https://upload.wikimedia.org/wikipedia/commons/6/69/Oued_El_Ghicha_Laghouat.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Ouled_DjellalList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Besbes ", "123", "https://upload.wikimedia.org/wikipedia/commons/3/3c/Commune_de_Besbes_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%A7%D9%84%D8%A8%D8%B3%D8%A8%D8%A7%D8%B3.jpg?uselang=fr"));
        lis.add(new Place_Model(" Sidi Khaled", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b8/Sidi_Khaled.JPG"));
        lis.add(new Place_Model("Ras El Miaad", "123", "https://upload.wikimedia.org/wikipedia/commons/0/09/APC_de_Ras_El_Miad_%D9%85%D9%82%D8%B1_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%B1%D8%A7%D8%B3_%D8%A7%D9%84%D9%85%D9%8A%D8%B9%D8%A7%D8%AF.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TouggourtList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Megarine", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4f/Megarine_Lake_Megarine_ouasis_Ouergla_3.JPG"));
        lis.add(new Place_Model("Sidi Slimane", "123", "https://www.algerie360.com/wp-content/uploads/2016/06/sidi-slimane-touggourt-echec-de-la-conciliation-entre-le-papc-et-les-elus.jpg?x30148"));
        lis.add(new Place_Model("Benaceur", "123", "https://upload.wikimedia.org/wikipedia/commons/1/11/Bennacer_%D8%A8%D9%86_%D9%86%D8%A7%D8%B5%D8%B1_-_panoramio.jpg"));
        lis.add(new Place_Model("Taibet", "123", "https://www.dknews-dz.com/data/images/article/thumbs/d-touggourt-plusieurs-operations-de-developpement-projetees-en-2022-2183e.jpg"));
        lis.add(new Place_Model("Balidat Ameur", "123", "https://www.vitaminedz.com/photos/89/89033-vue-centree-sur-la-mairie-de-balidat-ameur.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> OuedList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bayadha", "123", "https://fr.geneawiki.com/images/8/80/El-Oued_les_d%C3%B4mes.jpg"));
        lis.add(new Place_Model("Douar El Ma", "123", "https://upload.wikimedia.org/wikipedia/commons/b/be/El-Oued_The_dome.jpg"));
        lis.add(new Place_Model("Debila", "123", "https://1cf83a7d-a-62cb3a1a-s-sites.googlegroups.com/site/debilaouedsouf/home/images1.jpg?attachauth=ANoY7cqyyuv_TWnoTBFJpM_Z-sjzwJo1ejp_Fx3tYN-W69yRXrXvwn09fXYZ0jrcoAI4fwjMnKBvyXkMtPuzlL1bV0z8cRivSyxbGxYflKRRZLWDPky4cYJwMLObuVkrpRI110CeUlO5QAOHBaj8ms2ww3HGQ2-gWV4IEarnjpgAA776UkOILjO25W0GfvqK53mgcJ3lwnDS2VpYrEiff0BlFNXxvdmAYQ%3D%3D&attredirects=0"));
        lis.add(new Place_Model("Ben Guecha", "123", "https://cdn8.ouedkniss.com/350/medias/announcements/images/24922377/Photo2.jpg"));
        lis.add(new Place_Model("Hamraia", "123", "https://www.vitaminedz.com/photos/94/94309-vie-de-l-ancien-bordj-de-hamraia.jpg"));
        lis.add(new Place_Model("Kouinine", "123", "https://upload.wikimedia.org/wikipedia/commons/c/ce/Une_ancienne_ferme_de_palmier_abondonner_%C3%A0_kouinine.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> NaâmaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aïn Séfra", "123", "https://upload.wikimedia.org/wikipedia/commons/d/db/Vue_d_Ain_Sefra%2C_Alg%C3%A9rie.jpg"));
        lis.add(new Place_Model("Tiout", "123", "https://www.explo.com/media/catalog/category/tiout-oasis.jpg"));
        lis.add(new Place_Model("Mécheria", "123", "https://2.bp.blogspot.com/_2PhfywiW3E4/TS849rYm1aI/AAAAAAAAAMo/n3lJsAVEHto/s1600/Mecheria%2B-%2BLes%2Bgazelles.jpg"));
        lis.add(new Place_Model("Sfissifa", "123", "https://www.vitaminedz.com/photos/224/224027-ksar-sfissifa-naama.jpg"));
        lis.add(new Place_Model("Moghrar", "123", "https://www.vitaminedz.com/articles/6523/6523999.jpg"));
        lis.add(new Place_Model("Kasdir", "123", "https://www.vitaminedz.com/photos/182/182954-halfa-a-naama-commune-de-kasdir-vastes-etendues-de-terres.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> GhardaïaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bounoura", "123", "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Bounoura_2_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%A8%D9%86%D9%88%D8%B1%D8%A9.jpg/1280px-Bounoura_2_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%A8%D9%86%D9%88%D8%B1%D8%A9.jpg"));
        lis.add(new Place_Model("Berriane", "123", "https://upload.wikimedia.org/wikipedia/commons/2/26/Berrian_M%27Zab.JPG"));
        lis.add(new Place_Model("Dhayet Bendhahoua", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0e/Dhayet_Bendhahoua_%D8%B6%D8%A7%D9%8A%D8%A9_%D8%A8%D9%86_%D8%B6%D8%AD%D9%88%D8%A9.jpg"));
        lis.add(new Place_Model("El Atteuf", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c2/El-Atteuf_Ghardaia_Algeria.jpg"));
        lis.add(new Place_Model("El Guerrara", "123", "https://alchetron.com/cdn/el-guerrara-c70573e8-efe3-4913-ae32-4ed81a2bcf8-resize-750.jpeg"));
        return lis;
    }

    public static ArrayList<Place_Model> El_BayadhList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("El Bayadh", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6a/Rond_point_principal_El_Bayadh_centre_ville.jpg"));
        lis.add(new Place_Model("Bougtob", "123", "https://upload.wikimedia.org/wikipedia/commons/2/23/Bougtob_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%A8%D9%88%D9%82%D8%B7%D8%A8_%2848390171382%29.jpg"));
        lis.add(new Place_Model("Boussemghoun", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6a/Boussemghoune.jpg"));
        lis.add(new Place_Model("Brézina", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f5/La_mairie_Brezina_%D8%A8%D9%84%D8%AF%D9%8A%D8%A9_%D8%A8%D8%B1%D9%8A%D8%B2%D9%8A%D9%86%D8%A9.jpg"));
        lis.add(new Place_Model("El Abiodh Sidi Cheikh", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a0/Vue_dEl_Abiodh_Sidi_Cheikh%2C_Alg%C3%A9rie.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> OuarglaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        // lis.add(new Place_Model("El Allia","123","https://upload.wikimedia.org/wikipedia/commons/2/2b/El_Alia_Ouargla_-_panoramio_%2830%29.jpg"));
        lis.add(new Place_Model("El Hadjira", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6a/Boussemghoune.jpg"));
        lis.add(new Place_Model("Hassi Messaoud", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4d/20070227_OUARGLA_Camel_Race.jpg"));
        lis.add(new Place_Model("N'Goussa", "123", "https://i.pinimg.com/564x/59/a5/df/59a5df2420e1e2e91472871ae06cb700.jpg"));
        lis.add(new Place_Model("El Allia", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a0/Vue_dEl_Abiodh_Sidi_Cheikh%2C_Alg%C3%A9rie.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TimimounOList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Timimoun", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a1/Ksar_timimoun.jpg"));
        lis.add(new Place_Model("Aougrout", "123", "https://upload.wikimedia.org/wikipedia/commons/0/00/Aougrout.jpg"));
        lis.add(new Place_Model("Tinerkouk", "123", "https://upload.wikimedia.org/wikipedia/commons/2/2e/%D8%A7%D9%84%D8%A8%D8%B1%D8%AC_4.jpg"));
        lis.add(new Place_Model("Deldoul", "123", "https://www.vitaminedz.com/photos/4/4506-deldoul-adrar.jpg"));
        lis.add(new Place_Model("Ouled Said", "123", "https://www.vitaminedz.com/photos/196/196789-ksar-tindjillet-ouled-said-gourara-timimoun.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> BécharList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Abadla", "123", "https://upload.wikimedia.org/wikipedia/commons/d/d5/Oued_Guir_in_Abadla.jpg"));
        lis.add(new Place_Model("Béchar", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4d/Gourai.jpg"));
        lis.add(new Place_Model("Kénadsa", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6e/La_neige_%C3%A0_Kenadsa_%28Alg%C3%A9rie%29.jpg"));
        lis.add(new Place_Model("Taghit", "123", "https://upload.wikimedia.org/wikipedia/commons/f/fe/AG_006_large.jpg"));
        lis.add(new Place_Model("béni-ounif", "123", "https://www.algerie360.com/wp-content/uploads/2016/04/bechar-finalisation-dun-projet-de-protection-de-beni-ounif-des-inondations.jpg?x30148"));
        return lis;
    }

    public static ArrayList<Place_Model> AdrarList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bouda", "123", "https://www.vitaminedz.com/photos/21/21451-ksar-bouda.jpg"));
        lis.add(new Place_Model("Adrar", "123", "https://upload.wikimedia.org/wikipedia/commons/4/40/Adrar_buildings.jpg"));
        lis.add(new Place_Model("Aoulef", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a7/Ville_de_Aoulef_-_Adrar_%D9%85%D8%AF%D9%8A%D9%86%D8%A9_%D8%A7%D9%88%D9%84%D9%81_-_%D8%A7%D8%AF%D8%B1%D8%A7%D8%B1.jpg"));
        lis.add(new Place_Model("Zaouiet Kounta", "123", "https://www.vitaminedz.com/articles/6824/6824708.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> MeniaaList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("El Menia", "123", "https://www.lkeria.com/uploads/36524/220821/thumbnail/220821_2205071647560058407.jpeg"));
        lis.add(new Place_Model("Hassi Gara", "123", "https://upload.wikimedia.org/wikipedia/commons/f/f0/Distances_-_Hassi_Gara_%D8%AD%D8%A7%D8%B3%D9%8A_%D8%A7%D9%84%D9%82%D8%A7%D8%B1%D8%A9_-_%D9%85%D8%B3%D8%A7%D9%81%D8%A7%D8%AA.jpg"));
        lis.add(new Place_Model("Hassi Fehal", "123", "https://upload.wikimedia.org/wikipedia/commons/1/17/Hassi_El_Fehal_%D8%AD%D8%A7%D8%B3%D9%8A_%D8%A7%D9%84%D9%81%D8%AD%D9%84.jpg"));
        lis.add(new Place_Model("Mansoura", "123", "https://upload.wikimedia.org/wikipedia/commons/5/58/El_Golea-im-Tal%281586-19%29.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Béni_AbbèsList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Béni Abbès", "123", "https://ecotimesdz.com/wp-content/uploads/2021/03/beni-abbes.jpg"));
        lis.add(new Place_Model("Igli", "123", "https://upload.wikimedia.org/wikipedia/commons/d/dc/Igli.JPG"));
        lis.add(new Place_Model("Kerzaz", "123", "https://upload.wikimedia.org/wikipedia/commons/6/68/Kerzzaz-saoura.jpg"));
        lis.add(new Place_Model("Ksabi", "123", "https://www.aps.dz/media/k2/items/cache/1e50625559bcdab6a549d7589d0eab24_M.jpg"));
        lis.add(new Place_Model("El Ouata", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a1/El_Ouata_-_B%C3%A9char_%D8%A7%D9%84%D9%88%D8%A7%D8%AA%D8%A9_-_%D8%A8%D8%B4%D8%A7%D8%B1_%2849066116877%29.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> In_SalahList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("In Salah", "123", "https://upload.wikimedia.org/wikipedia/commons/5/52/InSalah%281991%29.jpg"));
        lis.add(new Place_Model("In Ghar", "123", "https://upload.wikimedia.org/wikipedia/commons/b/b6/Ville_de_Inghar_%D9%85%D8%AF%D9%8A%D9%86%D8%A9_%D8%A7%D9%8A%D9%86%D8%BA%D8%B1.jpg"));
        lis.add(new Place_Model("Foggaret Ezzaouia", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0f/Ain_El_Hadjadj_%D8%B9%D9%8A%D9%86_%D8%A7%D9%84%D8%AD%D8%AC%D8%A7%D8%AC_02.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TamanrassetList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Hoggar", "123", "https://upload.wikimedia.org/wikipedia/commons/0/0e/Hoggar_dpuis_assekrem.jpg"));
        lis.add(new Place_Model("Abalessa", "123", "https://www.algerie360.com/wp-content/uploads/2010/02/ouverture-a-tamanrasset-dun-festival-international-des-arts-de-lahaggar.jpg?x30148"));
        lis.add(new Place_Model("Idlès", "123", "https://upload.wikimedia.org/wikipedia/commons/0/07/Ideles1.jpg"));
        lis.add(new Place_Model("Tazrouk", "123", "https://www.algerie360.com/wp-content/uploads/2014/08/tamanrasset-tazrouk-destination-privilegiee-des-estivants.jpg?x30148"));
        lis.add(new Place_Model("In Amguel", "123", "https://upload.wikimedia.org/wikipedia/commons/c/c9/In_Amguel_-_Tamanrasset_%D8%A7%D9%86_%D8%A7%D9%85%D9%82%D9%84_-_%D8%AA%D9%85%D9%86%D8%B1%D8%A7%D8%B3%D8%AA_01.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> TindoufList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Tindouf", "123", "https://upload.wikimedia.org/wikipedia/commons/8/85/Tindouf_%D8%AA%D9%86%D8%AF%D9%88%D9%81_3.jpg"));
        lis.add(new Place_Model("Hassi Khébi", "123", "https://upload.wikimedia.org/wikipedia/commons/a/a6/Hassi_Khebi_%D8%AD%D8%A7%D8%B3%D9%8A_%D8%AE%D8%A8%D9%8A.jpg"));
        lis.add(new Place_Model("Oum el Assel", "123", "https://upload.wikimedia.org/wikipedia/commons/4/4a/Oum_El_Assel_-_Tindouf_%D8%A7%D9%85_%D8%A7%D9%84%D8%B9%D8%B3%D9%84_-_%D8%AA%D9%86%D8%AF%D9%88%D9%81.jpg"));
        lis.add(new Place_Model("Bou Bernous", "123", "https://upload.wikimedia.org/wikipedia/commons/1/10/Tindouf_-_Le_Mouggar_dans_les_ann%C3%A9es_1970.jpg"));
        lis.add(new Place_Model("Gare Djebilet ", "123", "https://www.algerie-eco.com/wp-content/uploads/2019/11/gisement-de-fer-de-gara-djebilet.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> DjanetList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Bordj El Houasse", "123", "https://upload.wikimedia.org/wikipedia/commons/7/72/Vall%C3%A9e_d%27Iherir%2C_commune_de_Bordj_El_Haouas%2C_wilaya_d%27Illizi%2C_Alg%C3%A9rie.jpg"));
        lis.add(new Place_Model("Djanet", "123", "https://upload.wikimedia.org/wikipedia/commons/2/28/Djanet.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> IlliziList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Illizi", "123", "https://upload.wikimedia.org/wikipedia/commons/e/e5/Illizi_nature.jpg"));
        lis.add(new Place_Model("Bordj Omar Driss", "123", "https://www.vitaminedz.com/photos/92/92156-architecture-a-l-entree-de-la-commune-de-bordj-omar-driss.jpg"));
        lis.add(new Place_Model("Debdeb", "123", "https://www.elmoudjahid.dz/storage/images/article/7aaa563dd92e85d2f20a961009b9b5c7.jpg"));
        lis.add(new Place_Model("In Amenas", "123", "https://upload.wikimedia.org/wikipedia/commons/6/66/Monument_-_In_Amenas_%D8%A7%D9%86_%D8%A7%D9%85%D9%8A%D9%86%D8%A7%D8%B3_-_%D8%B0%D9%83%D8%B1%D9%89_%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%82%D9%84%D8%A7%D9%84_-_panoramio.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> Bordj_Badji_MokhtarList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("Aéroport de Bordj Mokhtar", "123", "https://media.gettyimages.com/photos/algeria-bordj-mokhtar-military-airport-near-the-algerianmalian-border-picture-id647239748?s=2048x2048"));
        lis.add(new Place_Model("Hôpital de Bordj Badji Mokhtar", "123", "https://leprovincial.dz/wp-content/uploads/2022/01/d-lappareil-dimagerie-medicale-en-panne-04be6.jpg"));
        lis.add(new Place_Model("Wilaya de Bordj Badji Mokhtar", "123", "https://fibladi.com/news/fr/wp-content/uploads/sites/2/2021/05/7298f885a7b7213ae67fb39f9e9b67b1.jpg"));
        return lis;
    }

    public static ArrayList<Place_Model> In_GuezzamList() {
        ArrayList<Place_Model> lis = new ArrayList<>();
        lis.add(new Place_Model("In Guezzam", "123", "https://www.algerie-eco.com/wp-content/uploads/2018/08/in-guezzam.jpg"));
        lis.add(new Place_Model("Tin Zaouatine", "123", "https://upload.wikimedia.org/wikipedia/commons/6/6e/Tinzaouaten.jpg"));
        return lis;
    }
}


