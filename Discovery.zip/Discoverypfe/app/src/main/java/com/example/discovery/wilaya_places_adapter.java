
package com.example.discovery;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class wilaya_places_adapter extends RecyclerView.Adapter<wilaya_places_adapter.ViewHolder> {

    public ArrayList<Place_Model> items_list = new ArrayList<>();
    private Context context;
    int exists = 0;



    public wilaya_places_adapter(ArrayList<Place_Model> items_list, Context context) {
        this.context = context;
        this.items_list = items_list;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_layout, parent, false);
        return new wilaya_places_adapter.ViewHolder(view);    }
// click on the icon of gps to reach to the wanted place
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.name.setText(items_list.get(position).getName());
        holder.position.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(items_list.get(position).getName()));
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                context.startActivity(mapIntent);
            }
        });
        Picasso.get().load(items_list.get(position).getImage()).into(holder.place_image);

    }


    @Override
    public int getItemCount() {
        return items_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView place_image  ;
        TextView name ;
        MaterialCardView position ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            place_image = itemView.findViewById(R.id.place_image);
            name = itemView.findViewById(R.id.place_name);
            position = itemView.findViewById(R.id.position);
        }
    }
}
