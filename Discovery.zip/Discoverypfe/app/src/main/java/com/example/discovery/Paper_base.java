package com.example.discovery;

public class Paper_base {
    public static UserModel CurrentUser ;
    public static final String UserEmail = "UserEmail";
    public static final String UserPassword = "UserPassword";
}
